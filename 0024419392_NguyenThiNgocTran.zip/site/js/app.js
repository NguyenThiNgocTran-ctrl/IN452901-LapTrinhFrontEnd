  // Câu 2: viết JavaScript tại đây

const API_URL = 'http://localhost:4000';


const formatDateTime = (iso) =>
  new Date(iso).toLocaleString('vi-VN', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: '2-digit', year: 'numeric',
  });

const formatSeats = (event) => {
  const capacity = Number(event.capacity) || 0;
  const registered = Number(event.registeredCount) || 0;
  const remaining = capacity - registered;

  if (remaining <= 0) {
    return 'Hết chỗ';
  }
  return `Còn ${remaining}/${capacity} chỗ`;
};

const renderEvents = (events) => {
  const eventList = document.getElementById('event-list');
  if (!eventList) return;

  const cards = events.map((event) => {
    const article = document.createElement('article');
    article.className = 'event-card';

        const img = document.createElement('img');
    img.setAttribute('src', 'img/event.svg');
    img.setAttribute('alt', `Hình minh hoạ ${event.name}`);

    const body = document.createElement('div');
    body.className = 'card-body';

        const title = document.createElement('h2');
    title.className = 'card-title';

    const link = document.createElement('a');
    link.setAttribute('href', `event-detail.html?id=${encodeURIComponent(event.id)}`);
    link.textContent = event.name;
    title.appendChild(link);

    
    const timeWrapper = document.createElement('p');
    timeWrapper.className = 'card-meta';

    const timeEl = document.createElement('time');
    timeEl.setAttribute('datetime', event.startTime);
    timeEl.textContent = formatDateTime(event.startTime);
    timeWrapper.appendChild(timeEl);

    
    const locationEl = document.createElement('p');
    locationEl.className = 'card-meta';
    locationEl.textContent = event.location;

    
    const seatsEl = document.createElement('p');
    seatsEl.className = 'card-seats';
    const seatText = formatSeats(event);

    if (seatText === 'Hết chỗ') {
      const badge = document.createElement('span');
      badge.className = 'badge-full';
      badge.textContent = seatText;
      seatsEl.appendChild(badge);
    } else {
      seatsEl.textContent = seatText;
    }

    body.append(title, timeWrapper, locationEl, seatsEl);
    article.append(img, body);
    return article;
  });

  eventList.replaceChildren(...cards);
};

const loadEvents = async (keyword = '') => {
  const statusEl = document.getElementById('status');
  const trimmedKeyword = keyword.trim();

  if (statusEl) {
    statusEl.textContent = 'Đang tải...';
  }

  try {
    const params = new URLSearchParams();
    params.set('pageSize', '50');
    if (trimmedKeyword !== '') {
      params.set('q', trimmedKeyword);
    }

    const response = await fetch(`${API_URL}/api/events?${params.toString()}`);

    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }

    const data = await response.json();
    const items = Array.isArray(data.items) ? data.items : [];

    renderEvents(items);

    if (statusEl) {
      if (items.length === 0) {
        statusEl.textContent = 'Không có sự kiện nào khớp từ khoá.';
      } else {
        statusEl.textContent = `Tìm thấy ${items.length} sự kiện`;
      }
    }
  } catch (error) {
    if (statusEl) {
      statusEl.textContent = 'Không tải được dữ liệu, vui lòng thử lại.';
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const searchForm = document.getElementById('search-form');
  const keywordInput = document.getElementById('keyword');

  if (searchForm && keywordInput) {
    searchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      loadEvents(keywordInput.value);
    });
  }

  loadEvents();
});
